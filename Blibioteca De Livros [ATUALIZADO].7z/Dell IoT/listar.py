import os
import csv

def listar_cliente():
    os.system('cls') or os.system('clear')  
    print("-------------LISTAR CLIENTES-------------")

    with open('clientes.csv', 'r', newline='', encoding='utf-8') as clientes_csv:
        reader = csv.DictReader(clientes_csv, delimiter=";")
        for cliente in reader:
            print("Nome:", cliente['nome'])
            print("CPF:", cliente['cpf'])
            print("RG:", cliente['rg'])
            print('\n\r')

def listar_livro():
    os.system('cls') or os.system('clear')  
    print("-------------LISTAR LIVROS-------------")

    with open('livros.csv', 'r', newline='', encoding='utf-8') as livros_csv:
        reader = csv.DictReader(livros_csv, delimiter=";")
        for livros in reader:
            print("Nome:", livros['nome'])
            print("Código:", livros['codigo'])
            print("Autor:", livros['autor'])
            print("Ano de Lançamento:", livros['ano de lancamento'])
            print('\n\r')

def listar_emprestimo():
    os.system('cls') or os.system('clear')  
    emprestimo_csv = open("emprestimo.csv")
    dados_emprestimos = csv.DictReader(emprestimo_csv,delimiter=';')
    for emprestimo in dados_emprestimos:
        print(emprestimo)

def listar_atrasos():


    return 0