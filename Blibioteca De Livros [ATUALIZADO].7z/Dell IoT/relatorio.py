import os, csv
import pesquisar
from datetime import datetime

def listar_atrasos():
    emprestimos_csv = open("emprestimo.csv")
    dados_emprestimo = csv.DictReader(emprestimos_csv,delimiter=';')

    os.system('cls') or None
    print("------------RELATORIO DE LIVROS------------")
    print(f'{"CPF":15}', f'{"NOME":25}', f'{"TITULO":15}', f'{"EMPRESTIMO":15}', f'{"SITUAÇÃO":10}', f'{"DIAS"}')
    for emprestados in dados_emprestimo:
        data_emprestimo = datetime.strftime(emprestados['data_emprestimo'], '%d-%m-%Y')
        data_hoje = datetime.today()
        dias_atrasados = (data_hoje - data_emprestimo).days

        if dias_atrasados > 7:
            situacao = "atrasado"
            print(f'{emprestados["cpf"]:15}',
                  f'{emprestados["nome"]:25}',
                  f'{emprestados["titulo_livro"]:15}',
                  f'{emprestados["data_emprestimo"]:15}',
                  f'{situacao:10}',
                  f'{dias_atrasados}')