import os
import csv

def cadastrar_cliente():
    os.system('cls') or os.system('clear')  
    print("-------------CADASTRAR CLIENTE-------------")
    dados = {}


    nome = input("Digite seu nome: ")
    cpf = input("Digite seu CPF: ")
    rg = input("Digite seu RG: ")

    # Abre o arquivo para leitura e verifica se o cliente já existe pelo CPF '-'
    with open('clientes.csv', 'r', newline='', encoding='utf-8') as clientes_csv:
        reader = csv.DictReader(clientes_csv, delimiter=";")
        for row in reader:
            if row['cpf'] == cpf:
                print("Cliente já cadastrado com esse CPF.")
                return
    
    # Prepara os dados para escrever :P
    dados[cpf] = [nome, rg]
    coluna = ["cpf", "nome", "rg"]
    print(dados)
    print(coluna)

    # Abre o arquivo para escrever
    files_exist = os.path.isfile("clientes.csv")
    with open("clientes.csv","a",newline="", encoding="utf-8")as clientes_csv: #utf-8 padrão brasileiro para acentuação### as é um apelido
        cadastrar = csv.DictWriter(clientes_csv,fieldnames=coluna, delimiter=";",lineterminator='\r''\n')
        if not files_exist:
            cadastrar.writeheader()
        cadastrar.writerow({"cpf":cpf, "nome":nome, "rg":rg})
    print ("Cadastro realizado com sucesso!!")

def cadastrar_livro():
    os.system('cls') or os.system('clear')  
    dados = {}
    nome = input("Nome do livro: ")
    codigo = input("Codigo do livro: ")
    autor = input("Autor do livro: ")
    editora = input("Editora: ")
    ano_lancamento = input("Ano de lançamento do livro: ")

    # Abre o arquivo para leitura e verifica se o livro já existe pelo código
    with open('livros.csv', 'r', newline='', encoding='utf-8') as livros_csv:
        reader = csv.DictReader(livros_csv, delimiter=";")
        for row in reader:
            if row['codigo'] == codigo:
                print("Livro já cadastrado com esse código.")
                return
    
    # Prepara os dados para escrever
    dados[codigo] = [nome, autor, editora, ano_lancamento]
    colunas = ["nome", "codigo", "autor","editora", "ano de lancamento"]
    print(dados)
    print(colunas)

    # Abre o arquivo para escrever
    with open("livros.csv", "a", newline="", encoding="utf-8") as livros_csv:
        cadastrar = csv.DictWriter(livros_csv, fieldnames=colunas, delimiter=";", lineterminator="\r\n")
        if livros_csv.tell() == 0:  # Verifica se o arquivo está vazio
            cadastrar.writeheader()
        cadastrar.writerow({"nome": nome, "codigo": codigo, "autor": autor, "editora": editora, "ano de lancamento": ano_lancamento})
    print("Cadastro realizado com sucesso!")
