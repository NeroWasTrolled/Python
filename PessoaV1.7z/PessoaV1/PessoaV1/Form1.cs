﻿using PessoaV1.PessoaV1;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PessoaV1
{
    public partial class Cadastro : Form
    {
        public Cadastro()
        {
            InitializeComponent();
        }

        private void btFechar_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void Cadastro_Load(object sender, EventArgs e)
        {
            Pessoa pes = new Pessoa();
            List<Pessoa> pessoas = pes.listapessoa();
            dgvPessoa.DataSource = pessoas; 
            btEditar.Enabled = false;
            btExcluir.Enabled = false;  

        }
    }
}
