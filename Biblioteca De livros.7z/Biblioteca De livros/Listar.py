import os, csv

def Listar_Clientes():
    clientes_csv = open('clientes.csv', encoding='utf-8')
    dados = csv.DictReader(clientes_csv,delimiter=";")

    os.system('cls') or None
    print("---------LISTAGEM DE CLIENTES---------")
    print(f'{"CPF":15}',f'{"NOME":25}', "RG")
    for clientes in dados:
        print(f'{clientes["CPF":15]}', f'{clientes["NOME"]:25}',f'{clientes["rg"]}' )
    clientes_csv.close()

def Listar_Livros():
    livros_csv = open('livros.csv', encoding='utf-8')
    livros = csv.DictReader(livros_csv,delimiter=";")

    os.system('cls') or None
    print("---------LISTAGEM DE CLIENTES---------")
    print(f'{"CODIGO":10}',f'{"TITULO":20}', f'{"AUTOR":20}',f'{"EDITORA":20}',"ANO DE LANÇAMENTO")
    for livro in livros:
        print(f'{livro["CODIGO"]:10}',f'{livro["TITULO"]:20}', f'{livro["AUTOR"]:20}',f'{livro["EDITORA"]:20}',f'{livro["ANO DE LANÇAMENTO"]}')
    livros_csv.close()
    
def Listar_Emprestimo():
    emprestimos_csv = open('emprestimo.csv', encoding='utf-8')
    emprestimos = csv.DictReader(emprestimos_csv,delimiter=";")

    os.system('cls') or None
    print("---------LISTAGEM DE CLIENTES---------")
    print(f'{"CLIENTE":25}',f'{"TITULO DO LIVRO":25}',f'{"ANO DE LANÇAMENTO"}')
    for emprestimo in emprestimos:
        print(f'{emprestimo["CLIENTE"]:25}',f'{emprestimo["TITULO DO LIVRO"]:25}',f'{emprestimo["ANO DE LANÇAMENTO"]}')
    emprestimos_csv.close()