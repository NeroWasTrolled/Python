def Remover_Cliente():
    return 0
def Remover_Livro():
    return 0