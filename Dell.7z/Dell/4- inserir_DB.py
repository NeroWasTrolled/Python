import sqlite3

db = "estoque.db" #VARIAVEL PARA GUARDAR O NOME DO BANCO

conex = sqlite3.connect(db)
cursor = conex.cursor()

resp = 'S' #VARIAVEL DE CONTROLE DO WHILE

while(resp.upper() == 'S'):
    try:
        w_cod = int(input("Código do Produto: "))
        w_nome = input("Nome do Produto: ")
        w_qtde = int(input("Quantidade: "))
        w_estado = input("Estado: ")

        cursor.execute('''INSERT INTO tabProd(tbCod, tbNome, tbQtde, tbEstado)
            VALUES (?, ?, ?, ?)''', (w_cod, w_nome, w_qtde, w_estado))
        
        inserir = "s"


    except sqlite3.IntegrityError:
        print("==> Chave existente", w_cod)
    resp = input("Deseja continuar? (S/N)")

    if inserir == 's':
        conex.commit()
    cursor.close()
    conex.close()