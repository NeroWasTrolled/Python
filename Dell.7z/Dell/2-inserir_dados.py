import sqlite3 as s

conex = s.connect("estoque.db")
cursor = conex.cursor()

cursor.execute('''
    INSERT INTO tabProd(tbCod, tbNome, tbQtde, tbEstado)
                VALUES (4, "teclado", 15, "SP")''')
cursor.execute('''
    INSERT INTO tabProd(tbCod, tbNome, tbQtde, tbEstado)
                VALUES (3, "pendrive", 55, "SP")''')
cursor.execute('''
    INSERT INTO tabProd(tbCod, tbNome, tbQtde, tbEstado)
                VALUES (5, "mouse", 45, "SP")''')


conex.commit() # TRANSFERINDO A INFORMAÇÃO DE MEMORIA PARA O BANCO
cursor.close()
conex.close()