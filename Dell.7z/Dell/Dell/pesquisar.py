import csv
def pesquisar_cliente(nome_cliente):
    cliente_csv = open("cliente.csv") #abrindo arquivo CSV
    dados_cliente = csv.DictReader(cliente_csv, delimiter=";") #lendo counteudo

    for cliente in dados_cliente: #percorrendo as linhas do arquivo
        if(cliente["nome"].lower == nome_cliente.lower):
            nome = (cliente["nome"]) #listar o nome do cliente
            cpf = (cliente["rg"])
            return True,nome, cpf
        break
    return False

print(pesquisar_cliente("pietro"))


def pesquisar_livro():
    return 0