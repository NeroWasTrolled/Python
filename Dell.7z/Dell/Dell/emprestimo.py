import os
import csv
import pesquisar as p
from datetime import date
import datetime

def emprestar_livro():
    emprestimos = []

    print("------------------EMPRESTIMO DE LIVROS------------------")
    os.system('cls') or None

    nome_usuario = input("Nome do usuário")
    retorno = p.pesquisar_cliente(nome_usuario)

    if retorno[0] == True:
        codigo_livro = int(input("Código livro:"))
        existe = p.pesquisar_livro()
        if existe[0] != True:
            print("Livro não existe")
        else:
            data_emprestimo = date.today()

print(date.today.strftime('%d/%m/%YYYY'))

emprestar_livro()


