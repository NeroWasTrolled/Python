import cadastro
import listar
import remover
import emprestimo

resposta = "s"

while resposta == "s":
    menu = '''===================================================
    \r====[1] Cadastrar cliente                     =====
    \r====[2] Listar clientes                       =====
    \r====[3] Cadastrar livro                       =====
    \r====[4] Listar livro                          =====   
    \r====[5] Emprestar livro                       =====
    \r====[6] Listar emprestimos                    =====
    \r====[7] Listar livros atrasados               =====
    \r====[8] Remover cliente                       =====
    \r====[9] Remover livro                         =====
    \r====[10] Sair                                 =====
    \r==================================================='''                                  

    print(menu)

    opcao = int(input("Escolha uma opçao: "))

    if opcao == 1:
        cadastro.cadastrar_cliente()
    elif opcao == 2:
        listar.listar_cliente()
    elif opcao == 3:
        cadastro.cadastrar_livro()
    elif opcao == 4:
        listar.listar_livro()
    elif opcao == 5:
        emprestimo.emprestar_livro()
    elif opcao == 6:
        listar.listar_emprestimo()
    elif opcao == 7:
        listar.listar_atrasos()
    elif opcao == 8:
        remover.remover_cliente()
    elif opcao == 9:
        remover.remover_livro()
    elif opcao == 10:
        exit
        break
    else:
        print("Digite uma opçao valida!")

    resposta = input("Deseja continuar? [s/n]")
    