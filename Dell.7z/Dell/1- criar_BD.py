import sqlite3

conex = sqlite3.connect("estoque.db") #CRIAR CONEXÃO COM O BANCO

cursor = conex.cursor() # ENVIAR COMANDO PARA O BANCO

# EXECUTAR O CONJUNTO DOS COMANDOS
cursor.execute('''
        CREATE TABLE tabProd(tbCod INTEGER PRIMARY KEY,
        tbNOME TEXT,
        tbQtde INTEGER,
        tbEstado TEXT)''')

cursor.close() # FECHA CURSOR
conex.close() # FECHA CURSOR